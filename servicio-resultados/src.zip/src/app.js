require('dotenv').config();
const cors = require('cors');
const express = require('express');
const path = require('path');
const fs = require('fs');
const sequelize = require('./config/database');
const resultadoRoutes = require('./routes/resultadoRoutes');
const Resultado = require('./models/Resultado');
const Imagen = require('./models/Imagen');

// Asociaciones entre modelos
Resultado.hasMany(Imagen, { foreignKey: 'id_resultado', as: 'imagenes' });
Imagen.belongsTo(Resultado, { foreignKey: 'id_resultado', as: 'resultado' });

const app = express();
app.use(cors());
app.use(express.json());

// Crear carpeta de uploads si no existe
const uploadsDir = '/app/uploads';
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Servir archivos subidos
app.use('/uploads', express.static(uploadsDir));

app.use('/api/v1/resultados', resultadoRoutes);

app.get('/health/live', (req, res) => {
  res.status(200).json({ estado: 'activo', servicio: 'servicio-resultados' });
});

const PORT = process.env.PORT || 3003;

const conectarConReintentos = async (intentos = 5) => {
  for (let i = 1; i <= intentos; i++) {
    try {
      await sequelize.authenticate();
      console.log('Conexion a la base de datos exitosa');
      await sequelize.sync({ alter: true });
      console.log('Base de datos sincronizada');
      app.listen(PORT, () => {
        console.log('Servicio de resultados corriendo en el puerto ' + PORT);
      });
      return;
    } catch (error) {
      console.log('Intento ' + i + ' fallido. Reintentando en 5 segundos...');
      if (i === intentos) {
        console.error('No se pudo conectar:', error.message);
        process.exit(1);
      }
      await new Promise(res => setTimeout(res, 5000));
    }
  }
};

conectarConReintentos();